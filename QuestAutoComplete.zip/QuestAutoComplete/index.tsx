import "./styles.css";
import { definePluginSettings } from "@api/Settings";
import { Devs } from "@utils/constants";
import definePlugin, { OptionType } from "@utils/types";
import { React } from "@webpack/common";
import { initializeStores } from "./core/stores";
import {
    activeQuests,
    cleanupFunctions,
    isPluginStopping,
    parseProgressBarKey,
    progressBars,
    setPluginStopping,
} from "./core/state";
import { cleanupAllPills } from "./ui/notifications";
import { notify } from "./ui/notifications";
import { setupQuestButtonObserver, cleanupQuestButtonObserver } from "./ui/questButtons";
import { cancelQuest, checkAndResumeQuests } from "./quests/manager";
export const PLUGIN_VERSION = "2.0.1";

async function checkForUpdates() {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);

        const response = await fetch("https://api.github.com/repos/TheDeadDev/AutoQuestComplete/contents/Version.txt", { signal: controller.signal });
        clearTimeout(timeoutId);
        
        const data = await response.json();
        const text = atob(data.content);
        const remoteVersion = text.match(/PLUGIN_VERSION = ([\d.]+)/)?.[1];
        
        if (remoteVersion && remoteVersion !== PLUGIN_VERSION) {
            notify("Update Available", `New version ${remoteVersion} is available!`, "info");
        }
    } catch (e) {
        console.warn("[QuestAutoComplete] Failed to check for updates:", e);
    }
}

export const settings = definePluginSettings({
    showNotifications: {
        type: OptionType.BOOLEAN,
        description: "Notify you with current status of the quest, progress precentage & quest name and more",
        default: true,
    },
    notificationDuration: {
        type: OptionType.SLIDER,
        description: "how long the notifcations stay on screen (seconds)",
        default: 4,
        markers: [2, 4, 6, 8, 10],
    },
    autoResumeAfterReload: {
        type: OptionType.BOOLEAN,
        description: "Resume to the prevouise quest and contiune completing it after closing discord & reloading it",
        default: true,
    },
    autoAcceptAndComplete: {
        type: OptionType.BOOLEAN,
        description: "Auto accept new discoverd quests & complete them Automatically BETA",
        default: false,
    },
    allowMultipleQuests: {
        type: OptionType.BOOLEAN,
        description: "Auto complete more than a one quest at a time (use with caution, may get you banned) BETA",
        default: false,
    },
    autoAcceptDelay: {
        type: OptionType.SLIDER,
        description: "delay time to go accept a new quest & complete it (to prevent rate limit & suspicious activity)",
        default: 5,
        markers: [0, 5, 10, 15, 30, 60],
    },
});
function cleanupAll() {
    console.log("[QuestAutoComplete] Running full cleanup...");
    setPluginStopping(true);
    const questEntries = Array.from(activeQuests.entries());
    questEntries.forEach(([key, _]) => {
        const parsed = parseProgressBarKey(key);
        if (parsed) {
            try {
                cancelQuest(parsed.questId, parsed.userId);
            } catch (error) { }
        }
    });
    activeQuests.clear();
    progressBars.forEach(bar => {
        try { bar.remove(); } catch (error) { }
    });
    progressBars.clear();
    cleanupFunctions.forEach(cleanups => {
        cleanups.forEach(fn => {
            try { fn(); } catch (error) { }
        });
    });
    cleanupFunctions.clear();
    cleanupQuestButtonObserver();
    cleanupAllPills();
    console.log("[QuestAutoComplete] Cleanup completed");
}
export default definePlugin({
    name: "QuestAutoComplete",
    description: "Complete quests automatically & easily without doing them",
    authors: [{ name: "970417810587123723", id: 970417810587123723n }],
    tags: ["Activity", "Utility", "Fun"],
    settings,
    settingsAboutComponent: () => {
        const { QuestSettings } = require("./components/Settings");
        return <QuestSettings />;
    },
    start() {
        // Migrate old setting keys to new "accept" naming to preserve user preferences
        try {
            const store: any = (settings as any).store;
            if (store) {
                if (store.autoClaimAndComplete !== undefined && store.autoAcceptAndComplete === undefined) {
                    store.autoAcceptAndComplete = store.autoClaimAndComplete;
                    try { delete store.autoClaimAndComplete; } catch (e) { }
                }
                if (store.autoClaimDelay !== undefined && store.autoAcceptDelay === undefined) {
                    store.autoAcceptDelay = store.autoClaimDelay;
                    try { delete store.autoClaimDelay; } catch (e) { }
                }
                if (store.allowParallelQuests !== undefined && store.allowMultipleQuests === undefined) {
                    store.allowMultipleQuests = store.allowParallelQuests;
                    try { delete store.allowParallelQuests; } catch (e) { }
                }
            }
        } catch (e) {
            console.warn("[QuestAutoComplete] Settings migration failed:", e);
        }

        checkForUpdates();

        console.log(`[QuestAutoComplete] Plugin started - v${PLUGIN_VERSION}`);
        setPluginStopping(false);

        const initializeAndStart = async () => {
            let ready = initializeStores();
            let attempts = 0;
            while (!ready && !isPluginStopping && attempts < 10) {
                await new Promise(resolve => setTimeout(resolve, 1500));
                ready = initializeStores();
                attempts += 1;
            }
            if (!ready) {
                notify("Initialization Failed", "Could not initialize quest stores. Please open the Quests tab or reload Discord.", "error");
                return;
            }
            console.log("[QuestAutoComplete] Ready!");
            checkAndResumeQuests().catch(err => {
                console.warn("[QuestAutoComplete] Resume check failed:", err);
            }).finally(() => {
                setupQuestButtonObserver();
            });
        };

        setTimeout(initializeAndStart, 2000);
    },
    stop() {
        console.log("[QuestAutoComplete] Plugin stopping...");
        cleanupAll();
    },
});



